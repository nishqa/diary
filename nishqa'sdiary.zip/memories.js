let saveMemorySound = new Audio("https://www.soundjay.com/button/sounds/button-16.mp3"); 

window.onload = function() {
  displayMemories();
}

function saveMemory() {
  let memoryText = document.getElementById('memoryEntry').value;
  if(memoryText.trim() === "") {
    alert("Write something first!");
    return;
  }

  let memories = JSON.parse(localStorage.getItem('memories')) || [];
  let now = new Date();

  let mood = "default";
  if(memoryText.match(/happy|joy|fun|smile/i)) mood = "happy";
  else if(memoryText.match(/sad|lonely|cry|blue/i)) mood = "sad";
  else if(memoryText.match(/love|heart|romance|sweet/i)) mood = "love";

  memories.push({text: memoryText, date: now.toLocaleString(), mood: mood});
  localStorage.setItem('memories', JSON.stringify(memories));

  document.getElementById('memoryEntry').value = "";
  document.getElementById('savedMemoryMessage').innerText = "Memory Saved 💖";

  saveMemorySound.play();

  displayMemories();
}

function displayMemories() {
  let memoriesList = document.getElementById('memoriesList');
  memoriesList.innerHTML = "";
  let memories = JSON.parse(localStorage.getItem('memories')) || [];

  memories.forEach((memory) => {
    let div = document.createElement('div');
    div.className = "entry";
    let font = "Helvetica";
    if(memory.mood === "happy") font = "Comic Sans MS";
    else if(memory.mood === "love") font = "Cursive";
    div.style.fontFamily = font;

    div.innerHTML = `<p><strong>${memory.date}:</strong> ${memory.text}</p>`;
    memoriesList.appendChild(div);
  });
}